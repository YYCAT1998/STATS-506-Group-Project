# NHANES dataset

This folder contains 9 raw data files downloaded from [NHANES 2005-2006](https://wwwn.cdc.gov/nchs/nhanes/ContinuousNhanes/Default.aspx?BeginYear=2005) website.
